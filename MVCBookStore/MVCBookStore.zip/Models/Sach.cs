﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCBookStore.Models
{
    public class Sach
    {
        public int Masach { get; set; }
        public string Tensach { get; set; }
    }
}